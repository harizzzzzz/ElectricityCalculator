package com.example.assignment1_ict602;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText etUsed;
    EditText etRebate;
    Button btnCalculate;
    TextView tvOutputElectric;
    TextView tvOutputCharges;
    TextView tvOutputRebate;
    TextView tvOutputFinal;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsed= (EditText) findViewById(R.id.editTextNumberDecimalUsed);
        etRebate= (EditText) findViewById(R.id.editTextNumberDecimalRebate);
        btnCalculate = (Button) findViewById(R.id.btnCalculate);
        tvOutputElectric = (TextView) findViewById(R.id.tvOutputElectric);
        tvOutputRebate = (TextView) findViewById(R.id.tvOutputRebate);
        tvOutputCharges = (TextView) findViewById(R.id.tvOutputCharges);
        tvOutputFinal = (TextView) findViewById(R.id.tvOutputFinal);
        btnCalculate.setOnClickListener(this);
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {

        Button btnCalculate = findViewById(R.id.btnCalculate);
        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v.getId() == R.id.btnCalculate) {
                    try{
                    double used = Double.parseDouble(etUsed.getText().toString());
                    tvOutputElectric.setText("Total Electricity Used : " + used + " kWh");

                    double rebate = Double.parseDouble(etRebate.getText().toString());
                    tvOutputRebate.setText("Rebate(%) : " + rebate);

                    double charges ;
                    String stringUsed = etUsed.getText().toString();
                    String stringRebate = etRebate.getText().toString();

                        used = Double.parseDouble(stringUsed);
                        rebate = Double.parseDouble(stringRebate);
                    if (used <= 200) {
                        charges = used * 0.218;
                    } else if (used <= 300) {
                        charges = 200 * 0.218 + (used - 200) * 0.334;
                    } else if (used <= 600) {
                        charges = 200 * 0.218 + 100 * 0.334 + (used - 300) * 0.516;
                    } else {
                        charges = 200 * 0.218 + 100 * 0.334 + 300 * 0.516 + (used - 600) * 0.546;
                    }
                    tvOutputCharges.setText("Total Charges : RM" + charges);

                    double rebateTotal = charges * (rebate/100) ;
                    double finalCost = charges - rebateTotal ;
                    tvOutputFinal.setText("Final Cost : RM" + finalCost);

                    }catch (Exception e) {
                        Toast.makeText(getApplicationContext(), "Please fill the emptiness space", Toast.LENGTH_SHORT).show();
                    }
                    Button btnAboutMe = findViewById(R.id.btnAboutMe);

                    btnAboutMe.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            // Start the AboutMeActivity or navigate to the AboutMeFragment
                            Intent intent = new Intent(MainActivity.this, AboutMeActivity.class);
                            startActivity(intent);
                        }
                    });
                }
                }
            });
        };
        public boolean onCreationMenu (Menu menu) {
            MenuInflater inflater = getMenuInflater();
            inflater.inflate(R.menu.menu, menu);

            return true;
        }
    }
